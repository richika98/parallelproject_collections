
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {
	public static void main(String[] args) {
		
		Configuration cfg= new Configuration();	
		cfg.configure();
		SessionFactory factory= cfg.buildSessionFactory();
		Session session= factory.openSession();	
		
		
		//transaction is for DML commands
		Transaction trans= session.beginTransaction();
		
		Employee emp=(Employee) session.get(Employee.class,new Integer(1));//fetching the data from the database 
		session.save(emp);
		System.out.println(emp);
		
		
		emp.seteName("Swati");
		emp.seteSal(30000);
		session.update(emp);//update data
		System.out.println(emp);
		
		
		
		Employee emp1=(Employee) session.get(Employee.class,new Integer(101));//fetching the data from the database 
		session.delete(emp1);
		System.out.println("Deleted");	//delete data
		
		trans.commit();
		session.close();
		factory.close();
		
		
	}
}

	