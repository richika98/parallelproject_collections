
public class Employee {
private int eid;
private String eName;
private int eSal;


public Employee() {
	super();
}
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String geteName() {
	return eName;
}
public void seteName(String eName) {
	this.eName = eName;
}
public int geteSal() {
	return eSal;
}
public void seteSal(int eSal) {
	this.eSal = eSal;
}
public Employee(int eid, String eName, int eSal) {
	super();
	this.eid = eid;
	this.eName = eName;
	this.eSal = eSal;
}

public String toString() {
	return "Id:"+eid+"\nName:"+eName+"\nSalary:"+eSal;
}


}
