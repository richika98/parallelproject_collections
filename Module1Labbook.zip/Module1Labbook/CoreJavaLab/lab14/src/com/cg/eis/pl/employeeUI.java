package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;

public class employeeUI {
	public static void main(String[] args) {
		EmployeeService services= new EmployeeService();
		int empId=100,id=0;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("*********************************");
			System.out.println("1.Enter employee details");
			System.out.println("2.Check for insurance scheme");
			System.out.println("3.Display employee details");
			System.out.println("4.Exit Application");
			System.out.println("Enter your choice");
			String choice=sc.nextLine();
			switch(choice){
			case "1" :
				System.out.println("Enter employee name:");
				String name=sc.nextLine();
				System.out.println("Enter the salary:");
				int salary=sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the designation:");
				String designation=sc.nextLine();
				String scheme="";
				if (salary < 5000 && designation.equals("Clerk"))
					scheme="No Scheme";
				if((salary>5000 && salary <20000) && designation.equals("System Associate"))
					scheme="Scheme C";
				else if((salary>=20000 && salary <40000) && designation.equals("System Associate"))
					scheme="Scheme B";
				else if(salary >=40000 && designation.equals("Manager"))
					scheme="Scheme A";
				else
					scheme="No Scheme";
				Employee emp = new Employee(empId+1,name,designation, salary, scheme);
				 id=services.setEmployeeServices(emp);
				System.out.println("Data inserted!!");
				System.out.println("Your Employee id : "+id);
				break;
			case "2" :
				System.out.println("Enter your Salary :");
				salary=sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the designation:");
				designation=sc.nextLine();
				if (salary < 5000 && designation.equals("Clerk"))
					scheme="No Scheme";
				if((salary>5000 && salary <20000) && designation.equals("System Associate"))
					scheme="Scheme C";
				else if((salary>=20000 && salary <40000) && designation.equals("System Associate"))
					scheme="Scheme B";
				else if(salary >=40000 && designation.equals("Manager"))
					scheme="Scheme A";
				else
					scheme="No Scheme";
			
				System.out.println("Your scheme is :"+scheme);
				
				break;
			case "3" :
				System.out.println("Enter your employee id:");
				id=sc.nextInt();
				emp=services.getEmployeeServices(id);
				if(emp==null)
					System.out.println("Empoyee id doesn't exists!!");
				else
				{
					System.out.println("Employee name:"+emp.getEmpName());
					System.out.println("Employee salary :"+emp.getSalary());
					System.out.println("Employee designation : "+emp.getDesignation());
					System.out.println("Insurance Scheme : "+emp.getInsuranceScheme());
				}
				
				break;
			case "4" :
				sc.close();
				System.out.println("****Thanks for using this application****");
				System.exit(0);
				break;
				
			default :
					System.out.println("Invalid input");
			}
		}
	}
}
