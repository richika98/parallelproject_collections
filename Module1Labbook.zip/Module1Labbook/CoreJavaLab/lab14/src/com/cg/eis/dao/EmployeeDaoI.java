package com.cg.eis.dao;

import com.cg.eis.bean.Employee;

public interface EmployeeDaoI {
	Employee getEmployeeDao(int empId);
	void setEmployeeDao(Employee emp);
}
