package com.cg.eis.dao;

import java.util.HashMap;

import com.cg.eis.bean.Employee;

public class EmployeeDao implements EmployeeDaoI{

	HashMap<Integer,Employee> hm=null;
	
	public EmployeeDao() {
		hm= new HashMap<Integer,Employee>();
		Employee emp= new Employee(101, "Richika Kawtia", "Coder", 200000, "Scheme C");
		hm.put(100, emp);
	}
	
	@Override
	public Employee getEmployeeDao(int empId) {
		Employee emp=hm.get(empId);
		return emp;
	}

	@Override
	public void setEmployeeDao(Employee emp) {
		hm.put(emp.getEmpId(), emp);
		
	}

	

}
