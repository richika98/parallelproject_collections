package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDao;

public class EmployeeService implements EmployeeServiceI
{
	EmployeeDao empdao= new EmployeeDao();
	@Override
	public Employee getEmployeeServices(int empId) {
		Employee emp=empdao.getEmployeeDao(empId);
		return emp;
	}

	@Override
	public int setEmployeeServices(Employee emp) {
		empdao.setEmployeeDao(emp);
		return emp.getEmpId();
	}

}
