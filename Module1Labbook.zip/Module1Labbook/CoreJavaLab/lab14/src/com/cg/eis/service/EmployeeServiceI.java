package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeServiceI {
	Employee getEmployeeServices(int empId);
	int setEmployeeServices(Employee emp);
}
