package lab4;

import java.util.Scanner;

public class SumCubeDigit {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of digits:");
		int n=sc.nextInt();
		if(n<=0)
		{
			System.out.println("Invalid Input");
			System.exit(0);
		}
		System.out.println("Enter the number:");
		int num=sc.nextInt();
		int temp=num,nd=0;
		while(temp!=0) {
			nd++;
			temp/=10;
		}
		if(nd!=n) {
			System.out.println("Number does not contains "+n+" digits");
			System.exit(0);
		}
		int sum=getSum(num);
		System.out.println("Sum of cube of digits:"+sum);
		sc.close();
	}
	static int getSum(int num) {
		int sum=0,rem=0;
		while(num!=0) {
			rem=num%10;
			sum=sum+(int)Math.pow(rem,3);
			num/=10;
		}
		return sum;
	}
}
