package com.cg.eis.exception;

import java.util.Scanner;

class EmployeeException extends Exception{
	private int empSalary;
	public EmployeeException(int empSalary) {
		// TODO Auto-generated constructor stub
		this.empSalary=empSalary;
	}
	public String toString() {
		return "Employee salary should not be less than 3000";
	}
}
public class SalaryException {
	public static void main(String[] args)throws EmployeeException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the salary of the employee:");
		int empSalary=sc.nextInt();
		SalaryException.checkSalary(empSalary);
	}
	static void checkSalary(int empSalary)throws EmployeeException{
		if(empSalary<3000)
			throw new EmployeeException(empSalary);
		else
			System.out.println("Salary of the employee is :"+empSalary);
	}
}
