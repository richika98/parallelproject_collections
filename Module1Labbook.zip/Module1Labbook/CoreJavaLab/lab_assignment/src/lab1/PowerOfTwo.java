package lab1;

import java.util.Scanner;

public class PowerOfTwo {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		PowerOfTwo pot= new PowerOfTwo();
		System.out.println("Enter the number:");
		int n=sc.nextInt();
		boolean res=pot.checkNumber(n);
		if(res==true)
			System.out.println("The number is a power of 2");	
		else
			System.out.println("The number is not a power of 2");
		sc.close();
	}
	boolean checkNumber(int n) {
		int flag=0;
		while(n!=1) {
			if(n%2==0)
			{
				n/=2;
			}
			else {
				flag=1;
				break;
			}
		}
		if(flag==1)
			return false;
		else
			return true;
	}
}
