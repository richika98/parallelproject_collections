package lab1;

import java.util.Scanner;

public class NaturalDifference {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		NaturalDifference diff= new NaturalDifference();
		System.out.println("Enter the no of natural numbers:");
		int n=sc.nextInt();
		int minus=diff.calculateDifference(n);
		System.out.println("Difference:"+minus);
		sc.close();
	}
	int calculateDifference(int n) {
		int sum1=0,sum2=0;
		for(int i=1;i<=n;i++)
		{
			sum1=sum1+(int)Math.pow(i,2);
			sum2=sum2+i;
		}
		sum2=(int)Math.pow(sum2,2);
	//	System.out.println(sum1+" "+sum2 );
		return sum1-sum2;
	}
}
