package lab1;

import java.util.Arrays;
import java.util.Scanner;

public class IncreasingNumber {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number:");
		int num=sc.nextInt();
		if(num<=0) {
			System.out.println("Invalid Input");
			System.exit(0);
		}
		boolean res=IncreasingNumber.checkNumber(num);
		if(res==true)
			System.out.println("An Increasing number");
		else
			System.out.println("Not an Increasing number");
		sc.close();
	}
	static boolean checkNumber(int num) {
		int temp=num,nd=0;
		while(temp!=0) {
			nd++;
			temp/=10;
		}
		int i=nd-1;
		int arr1[]=new int[nd];
		int arr2[]=new int[nd];
		while(num!=0) {
			arr1[i]=num%10;
			arr2[i]=num%10;
			num/=10;i--;
		}
		Arrays.sort(arr1);
		if(Arrays.equals(arr1, arr2)==true)
			return true;
		else
			return false;
	}
	
}

