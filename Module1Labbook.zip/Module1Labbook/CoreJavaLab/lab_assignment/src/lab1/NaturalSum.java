package lab1;
import java.util.Scanner;

public class NaturalSum {
	public static void main(String[] args) {
		NaturalSum nat = new NaturalSum();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of naturals number");
		int n = sc.nextInt();
		int sum=nat.calculateSum(n);
		System.out.println("Sum :"+sum);
		sc.close();
	}
	int calculateSum(int n)
	{
		int i=1,sum=0,num=1;
	while(i<=n)
		{
			if(num%3==0 || num%5==0)
				{
				sum= sum+num;
				i++;
				}	
			num++;
		}
		return sum;
	}
}
