package lab10;

public class TimerQues implements Runnable{
	public static void main(String[] args) {
		TimerQues t= new TimerQues();
		Thread t1 = new Thread(t);
		t1.start();
	}
	public void run() {
		System.out.println("Timer started");
		while(true) {
			
			for(int i=1;i<=10;i++)
			{
				System.out.println(i);
				try {
					
					Thread.sleep(1000);
					
				}
				catch(InterruptedException ie) {
					ie.printStackTrace();
		}
		}
			System.out.println("Timer restarted");
	}
}
}
