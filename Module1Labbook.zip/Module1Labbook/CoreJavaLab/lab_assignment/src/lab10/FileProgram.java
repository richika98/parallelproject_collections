package lab10;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FileProgram {
	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("Source.txt");
		PrintWriter pw= new PrintWriter(fw);
		pw.println("Hello this is the source file");
		pw.println("Training session of Capgemini for the Trainees");
		pw.flush();
		pw.close();
		FileReader frs = new FileReader("Source.txt");
		FileWriter frt = new FileWriter("Target.txt");
		CopyDataThread cd = new CopyDataThread(frs,frt);
		cd.start();
//		br.close();
		
	}
}