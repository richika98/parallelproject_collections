package lab10;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread extends Thread{
	FileReader fr;
	FileWriter fw;
	

	public CopyDataThread(FileReader fr, FileWriter fw) {
		super();
		this.fr = fr;
		this.fw = fw;
	}


	public void run() {
		
		int s;
		int count=0;
		
		try
		{
			
			 BufferedReader br = new BufferedReader(fr);
			
			
			 while((s=br.read())!=-1)
			 {
				 if(count==10)
				 {
					 System.out.println("10 characters are copied");
					 count=0;
					 sleep(5000);
				 }
				 char c=(char)s;
				 fw.write(c);
				 count++;
			 }
			 
			 fw.flush();
			 fw.close();
			fr.close();
			 
			 System.out.println("File copied");
		
		}
		catch(InterruptedException | IOException e)
		{
			e.printStackTrace();
		}
	}
}

