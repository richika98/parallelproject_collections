package lab5;

import java.util.Scanner;

public class TrafficLight {
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("1.Red\n2.Yellow\n3.Green\n");
		 System.out.println("Select a color:");
		 int choice=sc.nextInt();
		 if(choice==1)
			 System.out.println("STOP");
		 else if(choice==2)
			 System.out.println("READY");
		 else if(choice==3)
			 System.out.println("GO");
		 else
			 System.out.println("Invalid option");
		 sc.close();
		 
	}
}
