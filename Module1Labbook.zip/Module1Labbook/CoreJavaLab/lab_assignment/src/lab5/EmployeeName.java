package lab5;

import java.util.Scanner;

class EmployeeNameException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String firstName,lastName;
	public EmployeeNameException( String firstName,String lastName) {
		// TODO Auto-generated constructor stub
		this.firstName=firstName;
		this.lastName=lastName;
	}
	public String toString() {
		return "First and the last name is blank";
	}
}
public class EmployeeName {
	public static void main(String[] args) throws EmployeeNameException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first name:");
		String firstName=sc.nextLine();
		System.out.println("Enter the last name:");
		String lastName=sc.nextLine();
		EmployeeName.checkName(firstName,lastName);
		sc.close();
	}
	static void checkName(String firstName,String lastName)throws EmployeeNameException{
		if(firstName.isEmpty() && lastName.isEmpty())
			throw new EmployeeNameException(firstName, lastName);
		else
			System.out.println(firstName+" "+lastName);
	}
}
