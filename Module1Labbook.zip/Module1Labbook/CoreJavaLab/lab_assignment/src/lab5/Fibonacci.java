package lab5;

import java.util.Scanner;

public class Fibonacci {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of n:");
		int n=sc.nextInt();
		if(n<=0) {
			System.out.println("Invalid Input");
			System.exit(0);
		}
		int result1=Fibonacci.NonRecursive(n);
		int result2=Fibonacci.Recursive(n);
		System.out.println(n+"th Fibonacci number:");
		System.out.println("Using recursive function:"+result2);
		System.out.println("Using non recursive function:"+result1);
		sc.close();
	}
	static int Recursive(int n) {
		if(n<=1)
			return n;
		else
			return Recursive(n-1) + Recursive(n-2);
	}
	static int NonRecursive(int n) {
		int a=1,b=1,c=0;
		for(int i=3;i<=n;i++) {
			c=a+b;
			a=b;
			b=c;
		}
		
		return c;
	}
}
