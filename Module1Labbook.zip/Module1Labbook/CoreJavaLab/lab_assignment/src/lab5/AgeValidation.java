package lab5;

import java.util.Scanner;

class AgeException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int age;
	public AgeException(int age) {
		// TODO Auto-generated constructor stub
		this.age=age;
	}
	public String toString() {
		return "Age of a person should be above 15";
	}
}
public class AgeValidation {
	public static void main(String[] args)  throws AgeException {
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the age:");
	int age=sc.nextInt();
	AgeValidation.checkAge(age);
	sc.close();
	}
	static void checkAge(int age) throws AgeException {
		if(age>15)
			System.out.println("Age is 15");
		else
			throw new AgeException(age);
	}
}
