
package lab13;

interface UserI {
	void setName(String name);
}

class UserClass {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

public class ques4 {
	public static void main(String[] args) {
		UserClass u = new UserClass();
		UserI ui = u::setName;
		ui.setName("Richika");
		System.out.println("Name:" + u.getName());
	}
}