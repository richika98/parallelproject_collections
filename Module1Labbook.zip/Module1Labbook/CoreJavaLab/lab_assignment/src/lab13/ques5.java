package lab13;

import java.util.Scanner;

interface factorial{int calculate(int num);}
public class ques5 {
	public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the number:");
			int n=sc.nextInt();
			ques5 q= new ques5();
			factorial f = q::calc;
			System.out.println(f.calculate(n));
			sc.close();
	}
	
	public int calc(int num)
	{
		int fact =1;
		for(int i=num;i>=1;i--)
			fact = fact*i;
		return fact;
	}
}
