package lab13;

import java.util.Scanner;

@FunctionalInterface
interface format{void addSpace(String str);}
public class ques2 {
	 public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String:");
		String str= sc.nextLine();
		format f=(String s)->{
			String res="";
			char []ch=s.toCharArray();
			for(int i=0;i<s.length();i++) {
			if(ch[i]!=' ')
				res=res+ch[i]+" " ;
			}
			System.out.println("Resultant String :"+res);
		};
		sc.close();
		 f.addSpace(str);
	}
}
