package lab13;

import java.util.Scanner;
@FunctionalInterface
interface LogIn{boolean check(String userName,String password);}
public class ques3 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter username:");
	String uName=sc.next();
	System.out.println("Enter password:");
	String password=sc.next();
	sc.close();
	LogIn l =  (String userName,String pass)->{
		if(userName.equals("capgemini") && pass.equals("capgemini123"))
			return true;
		else 
			return false;
	};
	System.out.println(l.check(uName, password));
}
}
