package lab13;

import java.util.Scanner;

interface Exponential{int numbers(int x,int y);}
public class ques1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first value");
		int x=sc.nextInt();
		System.out.println("Enter second value");
		int y=sc.nextInt();
		sc.close();
		Exponential e=(int a,int b)->{return (int)Math.pow(x, y);};
		System.out.println("X^y="+e.numbers(x,y));
	}
}
