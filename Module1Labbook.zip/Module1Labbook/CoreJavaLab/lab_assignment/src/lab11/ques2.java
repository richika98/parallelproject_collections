package lab11;

import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class ques2{
public static void main(String[] args) {
			
			ScheduledExecutorService services = Executors.newScheduledThreadPool(1);
			
			services.scheduleAtFixedRate(new DisplayTimer(), 5, 10, TimeUnit.SECONDS);
			System.out.println("Timer started");
		}
	}

	class DisplayTimer implements Runnable{
	
		@Override
		public void run() {
			
				System.out.println("Timer gets refreshed");
				System.out.println("Timer value is "+ new Date().getSeconds()+" seconds");
				
			
		}
	}