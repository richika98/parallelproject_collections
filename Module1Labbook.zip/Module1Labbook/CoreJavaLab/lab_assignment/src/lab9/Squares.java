package lab9;

import java.util.HashMap;
import java.util.Scanner;

public class Squares {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of elements:");
		int n=sc.nextInt();
		int []arr=new int[n];
		System.out.println("Enter the numbers:");
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		sc.close();
		HashMap<Integer, Integer> hm =Squares.getSquares(arr);
		System.out.println("Hash Map :");
		System.out.println(hm);
	}
	public static HashMap<Integer, Integer> getSquares(int arr[]) {
		HashMap<Integer, Integer> hm= new HashMap<Integer, Integer>();
		for(int i=0;i<arr.length;i++) {
			int sq=(int)Math.pow(arr[i],2);
			hm.put(arr[i],sq);
		}
		return hm;
	} 
}
