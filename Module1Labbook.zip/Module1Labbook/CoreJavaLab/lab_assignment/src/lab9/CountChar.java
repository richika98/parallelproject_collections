package lab9;

import java.util.HashMap;
import java.util.Scanner;

public class CountChar {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the no of characters");
	int n = sc.nextInt();
	char []arr= new char[n];
	System.out.println("Enter the characters:");
	for(int i=0;i<n;i++)
		arr[i]=sc.next().charAt(0);
	HashMap<Character, Integer> hm=CountChar.countCharacter(arr);
	System.out.println("Character with its count:");
	System.out.println(hm);
	sc.close();
	}
	public static HashMap<Character, Integer> countCharacter(char []arr) {
		HashMap<Character, Integer> hm = new HashMap<Character, Integer>();
		
		for(int i=0;i<arr.length;i++)
		{
			int count=1;
			if(hm.containsKey(arr[i]))
			{
				count++;
			}
			hm.put(arr[i],count);
		}
		return hm;
	}
}
