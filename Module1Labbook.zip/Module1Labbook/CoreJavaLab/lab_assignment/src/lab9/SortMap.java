package lab9;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class SortMap {
	public static void main(String[] args) {
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		Scanner sc = new Scanner(System.in);
		String value="";int i=0;
		System.out.println("Enter the no of values:");
		int n = sc.nextInt();
		System.out.println("Enter the values:");
		sc.nextLine();
		for( i=1;i<=n;i++)
		{
			value=sc.nextLine();
			hm.put(i, value);
		}
		System.out.println(hm);
		ArrayList<String> ll=getValues(hm);
		System.out.println("Sorted List :");
		System.out.println(ll);
		sc.close();
	}
	public static ArrayList<String> getValues(HashMap<Integer, String> hm) {
		ArrayList<String> ll = new ArrayList<String>();
		for(int i=1;i<=hm.size();i++)
		{
			ll.add(hm.get(i));
		}
		Collections.sort(ll);
		System.out.println(ll);
		return ll;
	}
}

