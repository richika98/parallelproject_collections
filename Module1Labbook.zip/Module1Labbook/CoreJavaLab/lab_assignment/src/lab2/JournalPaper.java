package lab2;
public class JournalPaper extends WrittenItem{
private String yearPublished;
public String getYearPublished() {
return yearPublished;
}
public void setYearPublished(String yearPublished) {
this.yearPublished = yearPublished;
}
public JournalPaper(String idNo, String title, int copiesCount, String author, String yearPublished) {
super(idNo, title, copiesCount, author);
this.yearPublished = yearPublished;
}
}