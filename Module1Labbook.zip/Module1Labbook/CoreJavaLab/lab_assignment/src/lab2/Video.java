package lab2;
public class Video extends MediaItem {
private String director;
private String genre;
public String getDirector() {
return director;
}
public void setDirector(String director) {
this.director = director;
}
public String getGenre() {
return genre;
}
public void setGenre(String genre) {
this.genre = genre;
}
public String getYearRealeased() {
return yearRealeased;
}
public void setYearRealeased(String yearRealeased) {
this.yearRealeased = yearRealeased;
}
public Video(String idNo, String title, int copiesCount, int runtime, String director, String genre,
String yearRealeased) {
super(idNo, title, copiesCount, runtime);
this.director = director;
this.genre = genre;
this.yearRealeased = yearRealeased;
}
private String yearRealeased;
}