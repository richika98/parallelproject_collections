package lab2;
public class Book extends WrittenItem{
public Book(String idNo, String title, int copiesCount, String author) {
super(idNo, title, copiesCount, author);
// TODO Auto-generated constructor stub
}
}