
package lab2;
public abstract class Item{
private String idNo;
private String title;
private int copiesCount;
public Item(String idNo, String title, int copiesCount) {
this.idNo = idNo;
this.title = title;
this.copiesCount = copiesCount;
}
@Override
public boolean equals(Object obj) {
if (this == obj)
return true;
if (obj == null)
return false;
if (getClass() != obj.getClass())
return false;
Item other = (Item) obj;
if (copiesCount != other.copiesCount)
return false;
if (idNo == null) {
if (other.idNo != null)
return false;
} else if (!idNo.equals(other.idNo))
return false;
if (title == null) {
if (other.title != null)
return false;
} else if (!title.equals(other.title))
return false;
return true;
}
@Override
public String toString() {
return "Item [idNo=" + idNo + ", title=" + title + ", copiesCount=" + copiesCount + "]";
}
public String getIdNo() {
return idNo;
}
public void setIdNo(String idNo) {
this.idNo = idNo;
}
public String getTitle() {
return title;
}
public void setTitle(String title) {
this.title = title;
}
public int getCopiesCount() {
return copiesCount;
}
public void setCopiesCount(int copiesCount) {
this.copiesCount = copiesCount;
}
public void print()
{
System.out.println(toString());
}
public void checkIn()
{
System.out.println("CheckIn method");
}
public void checkOut()
{
System.out.println("CheckOut method");
}
public void addItem()
{
System.out.println("Item added");
}
}