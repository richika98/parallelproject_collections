
package lab2;
public class MainClass {
public static void main(String[] args) {
// TODO Auto-generated method stub
Book b = new Book("102","Maths",2,"S.Chand");
System.out.println("Id:"+b.getIdNo());
System.out.println("Author:"+b.getAuthor());
System.out.println("Number of copies:"+b.getCopiesCount());
System.out.println("Title:"+b.getTitle());
}
}