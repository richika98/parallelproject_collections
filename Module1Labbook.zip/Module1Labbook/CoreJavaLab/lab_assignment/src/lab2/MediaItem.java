
package lab2;
public abstract class MediaItem extends Item {
private int runtime;
public MediaItem(String idNo, String title, int copiesCount, int runtime) {
super(idNo, title, copiesCount);
this.runtime = runtime;
}
public int getRuntime() {
return runtime;
}
public void setRuntime(int runtime) {
this.runtime = runtime;
}
}