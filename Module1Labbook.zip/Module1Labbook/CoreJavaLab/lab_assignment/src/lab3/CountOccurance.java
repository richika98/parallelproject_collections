package lab3;

import java.util.Scanner;

public class CountOccurance {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of characters in the array:");
		int n=sc.nextInt();
		char arr[]= new char[n];
		System.out.println("Enter the characters:");
		for(int i=0;i<n;i++)
			arr[i]=sc.next().charAt(0);
		getCount(arr);
		sc.close();
	}
	static void getCount(char arr[]) {
		int count[]=new int[255];
		int find=0,i=0;
		char ch[] = new char[arr.length];
		for ( i = 0; i < arr.length; i++) 
			count[arr[i]]++;
		for( i=0;i<arr.length;i++)
		{
			ch[i]=arr[i];
			find=0;
			for(int j=0;j<=i;j++)
			{
				if(arr[i]==ch[j])
					find++;
			}
			if(find==1)
				System.out.println(arr[i]+" occurs "+count[arr[i]]+" times");
		}
		 
	}
}

