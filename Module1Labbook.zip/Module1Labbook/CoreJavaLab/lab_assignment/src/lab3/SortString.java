package lab3;

import java.util.Arrays;
import java.util.Scanner;

public class SortString {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i=0;
		System.out.println("Enter the no of elements in the array:");
		int n=sc.nextInt();
		sc.nextLine();
		if(n<=0) {
			System.out.println("Invalid Input");
			System.exit(0);
		}
		String []arr=new String[n];
		System.out.println("Enter the elements:");
		for( i=0;i<n;i++)
			arr[i]=sc.nextLine();
		String result[]= sortArray(arr);
		System.out.println("Sorted Array:");
		for(i=0;i<n;i++)
			System.out.println(result[i]);
		sc.close();	
	}
	static String[] sortArray(String arr[])
	{
		String []arr2=new String[arr.length];
		for(int i=0;i<arr.length;i++)
		{
			char []a=arr[i].toCharArray();
			Arrays.sort(a);
			int len=a.length;		//Strings are sorted
				if(arr.length%2==0)
				{
					for(int j=0;j<len;j++)
						if(i<arr.length/2)
						
							a[j]=Character.toUpperCase(a[j]);
						else
						
							a[j]=Character.toLowerCase(a[j]);
				}
			else {
				for(int j=0;j<len;j++)
					if(i<arr.length/2+1)
						a[j]=Character.toUpperCase(a[j]);
					else
						a[j]=Character.toLowerCase(a[j]);
				}
				arr2[i]="";
				for(int k =0;k<a.length;k++)			// convert the char [] to string
					arr2[i]+=Character.toString(a[k]);
			}		
		return Arrays.copyOf(arr2,arr2.length);
	}
}


