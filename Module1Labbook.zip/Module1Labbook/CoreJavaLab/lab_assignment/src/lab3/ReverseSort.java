package lab3;

import java.util.Arrays;
import java.util.Scanner;

public class ReverseSort {
public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the no of elements in the aray:");
	int n=sc.nextInt();
	int i=0;
	if(n<=0) {
		System.out.println("Invalid Input");
		System.exit(0);
	}
	int num[]=new int[n];
	System.out.println("Enter the elements:");
	for( i=0;i<n;i++)
		num[i]=sc.nextInt();
	int result[]=getSorted(num);
	for( i=0;i<n;i++)
		System.out.println(result[i]);
	sc.close();
}
	static int[] getSorted(int num[]) {
		int n=num.length;
		String str="";
		for(int i=0;i<n;i++)
		{
			str="";
			String s=String.valueOf(num[i]);
			for(int j=s.length()-1;j>=0;j--) 
			{
				str=str+s.charAt(j);
			}
			num[i]=Integer.valueOf(str);
		}
		Arrays.sort(num);
		return num;
	}
}