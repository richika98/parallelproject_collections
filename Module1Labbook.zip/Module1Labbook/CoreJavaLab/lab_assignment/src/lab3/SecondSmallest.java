package lab3;

import java.util.Arrays;
import java.util.Scanner;

public class SecondSmallest {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the no of elements in the array");
		int n=sc.nextInt();
		if(n<=0) {
			System.out.println("Invalid Input");
			System.exit(0);
		}
		int num[]=new int[n];
		System.out.println("Enter the array elements:");
		for(int i=0;i<n;i++)
			num[i]=sc.nextInt();
		int smallNum=SecondSmallest.getSecondSmallest(num);
		System.out.println("Second Smallest number:"+smallNum);
		sc.close();
	}
	static int getSecondSmallest(int []num)	
	{
		 Arrays.sort(num);
		 return num[1];
	}
}
