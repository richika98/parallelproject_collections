package lab8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CountData {
public static void main(String[] args) throws IOException{
	BufferedReader br = new BufferedReader(new FileReader("MyFile.txt"));
	int countWord=0,countLine=0,countChar=0;
	//for(int i=0;i<)
	String line=br.readLine();
	//countLine++;
	while(line!=null)
	{
		countLine++;
		line=br.readLine();
	}
	br.close();
	BufferedReader br2 = new BufferedReader(new FileReader("MyFile.txt"));
	for(int i=0;i<countLine;i++)
	{
		line=br2.readLine();
		String word[]=line.split(" ");
		countWord+=word.length;
		for(int j=0;j<word.length;j++)
		{
			countChar+=word[j].length();
		}
	}
	System.out.println("No of lines : "+countLine);
	System.out.println("No of words : "+countWord);
	System.out.println("No of characters : "+countChar);
	br2.close();
}
}
