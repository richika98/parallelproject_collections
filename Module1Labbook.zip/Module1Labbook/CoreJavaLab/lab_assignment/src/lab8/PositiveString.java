package lab8;

import java.util.Arrays;
import java.util.Scanner;

public class PositiveString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string:");
		String str=sc.nextLine();
		boolean result=checkPositive(str);
		if(result==true)
			System.out.println("Positive String");
		else
			System.out.println("Not a Positive String");
		sc.close();
	}

	 static boolean checkPositive(String str) {
		// TODO Auto-generated method stub
		char []ch=str.toCharArray();
		char []ch2=str.toCharArray();
		Arrays.sort(ch);
		if(Arrays.equals(ch, ch2))
			return true;
		else
			return false;
	}

}
