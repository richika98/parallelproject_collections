package lab8;

import java.util.Scanner;

public class Regitration {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Username:");
		String userName=sc.nextLine();
		boolean result=Validate(userName);
		if(result==true)
			System.out.println("Valid User Name");
		else
			System.out.println("Invalid User Name");
		sc.close();
		
	}

	 static boolean Validate(String userName) {
		// TODO Auto-generated method stub
		 String str2=userName.substring(0, userName.length()-4);
		 //System.out.println(str2);
		 if(str2.length()>=8 && userName.endsWith("_job"))
			 return true;
		 else
			 return false;
	}
	
}
