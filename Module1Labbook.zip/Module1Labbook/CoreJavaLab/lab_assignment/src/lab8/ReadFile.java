package lab8;
import java.io.*;

public class ReadFile {
	public static void main(String[] args) throws IOException{
		PrintWriter pw=new PrintWriter(new FileWriter("MyFile.txt"));
		pw.println("This is the first line");
		pw.println("This is the second line");
		pw.println("This is the third line");
		pw.flush();
		pw.close();
		BufferedReader br = new BufferedReader(new FileReader("MyFile.txt"));
		String str=br.readLine();
		int i=1;
		while( str !=null)
		{
			System.out.println(i+". "+str);
			i++;
			str=br.readLine();
		}
	}
}
