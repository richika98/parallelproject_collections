package lab8;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class CountDays {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter date in \"DD/MM/YYYY\" format ");
		String date=sc.nextLine();
		CountDays.getCount(date);
		sc.close();
	}
	public static void getCount(String d) {
		DateTimeFormatter dtf =  DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse(d, dtf);
		LocalDate today=LocalDate.now();
		Period period= Period.between(date, today);
		System.out.println("Duration : "+period.getYears()+" yrs "+
				period.getMonths()+" months "+period.getDays()+" days");
		
	} 
}
