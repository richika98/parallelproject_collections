package lab8;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileInformation {
	public static void main(String[] args) throws IOException{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the file name:");
		String fileName=sc.next();
		File fw = new File(fileName);
		System.out.println("File Exists: "+fw.exists());
		System.out.println("File is Readable: "+fw.canRead());
		System.out.println("File is Writable: "+fw.canWrite());
		String extension=fileName.substring(fileName.indexOf(".")+1);
		System.out.println("File Length:"+fw.length());
		System.out.println("File type:"+extension);
		sc.close();
		
	}
}
