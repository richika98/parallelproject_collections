package lab8;

import java.util.*;

public class StringIntegers {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the sequence of integers:");
		String str=sc.nextLine();
		StringTokenizer st = new StringTokenizer(str," ");
		int num=0,sum=0;
		while(st.hasMoreTokens())
		{
			String token=st.nextToken();
			System.out.println(token);
			num=Integer.parseInt(token);
			sum+=num;
		}
		System.out.println("Sum:"+sum);
		sc.close();
	}
}
