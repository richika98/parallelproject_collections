import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';
import { stringify } from '@angular/compiler/src/util';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {
service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
  }
ifExists=true;
message:string;
  transfer(data:any){
    let receiver:string=data.receiver;
    let sender:string=data.sender;
    let amount:number=data.amount;
    if(receiver=="" || amount==0 || sender=="")
    window.alert("Data not provided properly");
    else{
    this.message=this.service.transfer(sender,receiver,amount);
    this.ifExists=false;
  }
}

  ngOnInit() {
  }

}
