import { Component, OnInit } from '@angular/core';
import { MyServiceService, Account } from '../my-service.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  message:string;
ifExists:boolean=true;
  withdraw(data:any){
    let acc:string=data.account;
    let amount:number=data.amount;
    if(acc=="" || amount==0)
    window.alert("Data not provided properly");
    else{
    this.ifExists=false;
    this.message= this.service.withdraw(acc,amount);
    
  }
  }
}
