package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProject187023Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProject187023Application.class, args);
	}

}
