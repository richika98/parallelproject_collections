package com.cap.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import com.cap.beans.AccountBean;
import com.cap.beans.Transaction;
public class ActivityDao implements ActivityDaoI{
	
	HashMap<String,AccountBean> hm=null;	//storing customer details
	 HashMap<Transaction,String> trans=null;	//storing transactions
	 
	 
	public ActivityDao() {
		hm=new HashMap<String,AccountBean>();
		trans= new HashMap<Transaction,String>();
		AccountBean ab = new AccountBean("Richika", "9090442922", "Savings", "Kolkata", 1000);
		hm.put("RICH9090442922",ab);
	}

	public AccountBean getAccountDao(String accountNum) {	//Accessing account details
		
		AccountBean account=(AccountBean) hm.get(accountNum);
		return account;
		
	}
	
	
	public  String setAccountDao(String accNumber,AccountBean account) {	//storing account info in map
		
		AccountBean account2=(AccountBean) hm.get(accNumber);
		
		if(account2==null)
		{												//store only if the account doesn't exists 
			hm.put(accNumber, account);
	
			return accNumber;
		}
		
			return null;
	}


//storing transaction details in the map
	@Override
	public void setTransactionDao(String accNumber, Transaction transaction) {
		
		trans.put(transaction,accNumber);
	}

	@Override
	public  ArrayList printTransactionsDao(String accountNum) {
		
		
		ArrayList tran= new ArrayList();			//Retrieving transaction data from the map into the array list 
		Set s= trans.entrySet();
		Iterator t = s.iterator();
		while(t.hasNext())
		{
		Entry e = (Entry)t.next();
		String value=(String) e.getValue();
		Transaction key=(Transaction) e.getKey();
		if(value.equals(accountNum))
			{
			tran.add(key);
			}
		}
		return tran;	
	}
}
