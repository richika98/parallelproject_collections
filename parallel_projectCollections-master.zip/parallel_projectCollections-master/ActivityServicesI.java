package com.cap.services;

import com.cap.beans.AccountBean;
import com.cap.beans.Transaction;

public interface ActivityServicesI {
	AccountBean getAccountServices(String accNumber);
	long transferServices(String accountNum,String raccountNum,long amount);
	String setAccountServices(AccountBean account);
	public boolean withdrawServices(String accountNum, long amount);
	public boolean depositServices(String accountNum, long amount);
	void setTransaction(String accNumber,Transaction transaction);
	void printTransactions(String accountNum);
}
