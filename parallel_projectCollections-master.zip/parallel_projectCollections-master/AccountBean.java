package com.cap.beans;

public class AccountBean {
	private String custName,mobileNumber,accountType,custAddress;
	private long balance;
	public AccountBean(String custName, String mobileNumber, String accountType, String custAddress, long balance) {
		super();
		this.custName = custName;
		this.mobileNumber = mobileNumber;
		this.accountType = accountType;
		this.custAddress = custAddress;
		this.balance = balance;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public String toString() {
		return custName+" "+custAddress+" "+mobileNumber+" "+accountType+" "+balance;
	}
}