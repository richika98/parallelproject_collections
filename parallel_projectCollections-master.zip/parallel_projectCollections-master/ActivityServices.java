package com.cap.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Pattern;

import com.cap.beans.AccountBean;
import com.cap.beans.Transaction;
import com.cap.dao.ActivityDao;

import ValidationException.BalanceException;
import ValidationException.InvalidAccountException;
import ValidationException.InvalidNameException;
import ValidationException.MobileNumberException;

public class ActivityServices implements ActivityServicesI{
	ActivityDao ad = new ActivityDao();
	@Override
	public AccountBean getAccountServices(String accNumber) {
		
		AccountBean account=ad.getAccountDao(accNumber);	//Retrieving account info from the dao
		return account;
	}

	//passing the account details to the dao
	@Override
	public String setAccountServices(AccountBean account) {	//saving data through the dao
		
		char []ch=account.getCustName().toCharArray();
		String accountNum="";
		for(int i=0;i<4;i++) {
			ch[i]=Character.toUpperCase(ch[i]);
			accountNum=accountNum+ch[i];				//generating account number
		}
		accountNum=accountNum+account.getMobileNumber();	
	
		String res=ad.setAccountDao(accountNum,account);
		return res;
	}

	
	//for transferring amount to another account
	@Override
	public long transferServices(String saccountNum, String raccountNum, long amount) {
		
		if(saccountNum.equals(raccountNum))
		{
			System.out.println("Receiver and sender account number can't be same");
			return 0;
		}
		AccountBean account=ad.getAccountDao(saccountNum);
		AccountBean account2=ad.getAccountDao(raccountNum);
		if(account==null) {
			System.out.println("Your account doesn't exists!!");
			return 0;
		}
		else {
		if(account2==null) {
			System.out.println("Receiver's account doesn't exists!!");
			return 0;
		}
		else {
			long senderBal=account.getBalance();
			long receiverBal=account2.getBalance();
			if(amount>senderBal)					//checking if the sender has sufficient balance or not
				return 0;
			else {
			senderBal=senderBal-amount;
			account.setBalance(senderBal);
			receiverBal=receiverBal+amount;
			account2.setBalance(receiverBal);
			ad.setAccountDao(saccountNum,account);
			ad.setAccountDao(raccountNum,account2);
			return senderBal;
			}
		}}
	}

	
	//withdraw money from one's account
	@Override
	public boolean withdrawServices(String accountNum, long amount) {
		AccountBean account=ad.getAccountDao(accountNum);
		if(account==null) {
			System.out.println("Account doesn't exists");
			return false;
		}	
		else
		{
			long bal=account.getBalance();	//checking for the availability of the withdraw amount
			if(amount>bal)
				{System.out.println("Insufficient Balance");return false;}
			else {
				bal-=amount;
				account.setBalance(bal);
				System.out.println("Current Balance:"+bal);
				return true;
			}
		}
		
	}

	
	//for depositing money into your account
	@Override
	public boolean  depositServices(String accountNum, long amount) {
		
		AccountBean account=ad.getAccountDao(accountNum);
		if(account==null) {
			System.out.println("Account doesn't exists");
			return false;
		}	
		else
		{
			long bal=account.getBalance();	// deposits if the account exists 
			bal=bal+amount;
			account.setBalance(bal);
			System.out.println("Current Balance:"+bal);
			return true;
			}
		}


	//storing new transaction detail

	@Override
	public void setTransaction(String accNumber,Transaction transaction) {
		ad.setTransactionDao( accNumber, transaction);
		
	}

	//printing transaction of an account using ArrayList
	@Override
	public void printTransactions(String accountNum) {
		ArrayList<Transaction> al = ad.printTransactionsDao(accountNum);
		Iterator t = al.iterator();
		while(t.hasNext())
			System.out.println(t.next());
		
	
	}
	
	//validating for the name 
	public static void checkName(String custname) throws InvalidNameException {
		
		boolean res=Pattern.matches("[a-zA-Z]*", custname);
		if( res==false)
			throw new InvalidNameException(custname);
		
	}
	
	//validating for the account number
	 public static void validateAccountNumber(String accNum)throws InvalidAccountException{
		
		boolean res1=Pattern.matches("[A-Z]{4}[0-9]{10}", accNum);
		
	if(res1==false)
		throw new InvalidAccountException(accNum);
	}
	 
	 //validating for the mobile number
	public static void validateMobile(String mobileNumber) throws MobileNumberException {
		boolean res1=Pattern.matches("[0-9]{10}", mobileNumber);
		
		if(res1==false)
			throw new MobileNumberException(mobileNumber);
		}
	
	//validating for the amount entered
	 public static void validateBalance(long balance) throws BalanceException {
		String bal=String.valueOf(balance);
		boolean res1=Pattern.matches("[0-9]{0,15}", bal);
		if(res1==false)
			throw new BalanceException(balance);
	}
		
}

