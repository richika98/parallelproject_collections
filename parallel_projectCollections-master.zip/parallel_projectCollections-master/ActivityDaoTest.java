package com.cap.dao;

import org.junit.Test;

public class ActivityDaoTest {
	
	 /*
	  * test for withdraw amount 
	  */
	@Test
	public void testWithdraw() {
		
	}
}
