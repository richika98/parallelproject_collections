package com.cap.dao;

import java.util.ArrayList;

import com.cap.beans.AccountBean;
import com.cap.beans.Transaction;

public interface ActivityDaoI {
		AccountBean getAccountDao(String accountNum) ;
		public String setAccountDao(String accNumber,AccountBean account);
		void setTransactionDao(String accNumber,Transaction transaction);
		ArrayList<Transaction> printTransactionsDao(String accountNum);
}
