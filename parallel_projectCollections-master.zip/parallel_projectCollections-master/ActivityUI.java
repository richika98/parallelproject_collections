package com.cap.ui;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cap.beans.AccountBean;
import com.cap.beans.Transaction;
import com.cap.services.ActivityServices;

import ValidationException.BalanceException;
import ValidationException.InvalidAccountException;
import ValidationException.InvalidNameException;
import ValidationException.MobileNumberException;

public class ActivityUI {
	public static void main(String[] args)  {
		Scanner sc = new Scanner(System.in);
		ActivityServices services=new ActivityServices();
		int transid=100;String choice="";
		while(true)
		{
		
			System.out.println("----------------------");	
			System.out.println("1.Create Account\n2.Transfer Amount\n3.Withdraw\n4.Deposit\n5.Show Balance\n6.Print Transactions\n7.Exit");
	
			System.out.println("Enter the choice:");
			choice=sc.next();			
			switch(choice) {
			
			case "1" :		//CREATE ACCOUNT
				long balance=0;
				try {
					int option=0;String type="";			//data input
					sc.nextLine();
					System.out.println("Enter your name:");
					String custName=sc.nextLine();
					ActivityServices.checkName(custName);
					System.out.println("Enter your mobile number:");
					String number=sc.nextLine();
					ActivityServices.validateMobile(number);		//checks for valid mobile number
					do {
					System.out.println("Enter the account type:");
					System.out.println("1.Savings\n2.Current");		//iterates until the correct option is chosen
					 option=sc.nextInt();
					if(option==1)
						type="Savings";
					else if(option==2)
						type="Current";
					}
					while(option!=1 && option!=2);
					sc.nextLine();
					System.out.println("Enter the address:");
					String adr=sc.nextLine();
					System.out.println("Enter the initial balance:");
					balance=sc.nextLong();
					ActivityServices.validateBalance(balance);			//validating valid balance input
					AccountBean account = new AccountBean(custName, number, type, adr, balance);
					String res=services.setAccountServices(account);
					if(res==null)
						System.out.println("Account already exixts");
					else {
						System.out.println("Congrats!! Your account is created.");
						System.out.println("Your account number is:"+res);}
				}
				catch(InvalidNameException iae) {
					System.out.println("Invalid name input");
				}
				catch(MobileNumberException ne) {
					System.out.println("Mobile number should contain 10 digits");
				}
				catch(BalanceException be) {
					System.out.println("Out of range amount");
				}
				catch(InputMismatchException ime) {
					System.out.println("Give proper input");
				}
				catch(Exception e) {
					System.out.println("Oops!!Something went wrong!!");
				}
					
				break;
				
			case "2" :	//TRANSFER
				
				long amount=0;
				String accountNum="",raccountNum="";
				try{System.out.println("Enter your Account number:");
				 accountNum=sc.next();
				 ActivityServices.validateAccountNumber(accountNum);
				System.out.println("Enter the receiver's account number:");
				raccountNum=sc.next();
				ActivityServices.validateAccountNumber(raccountNum);		//checks for valid account number
				}
				catch(InvalidAccountException ie) {
					System.out.println("Invalid Account Number");break;
				}
				try {
				System.out.println("Enter the amount to transfer:");
				 amount=sc.nextLong();
				 ActivityServices.validateBalance(amount);
				}
				catch(BalanceException be) {
					System.out.println("Out of range amount");
				}
				catch(InputMismatchException ime) {
					System.out.println("Give proper input");
				}
				long bal=services.transferServices(accountNum,raccountNum,amount);
				if(bal!=0) {
					System.out.println("Amount transferred successfully!!");	
					transid+=10;														
					Transaction t = new Transaction(transid, amount, "transfer",raccountNum , "--	");	//transaction details
					services.setTransaction(accountNum, t);
					transid+=10;
					Transaction t2 = new Transaction(transid, amount, "transfer","--		" , accountNum);
					services.setTransaction(raccountNum, t2);
				}
				else
					System.out.println("Oops!!Amount transfer failed");
				break;
			case "3" :		//WITHDRAW
				amount=0;accountNum="";
				try{System.out.println("Enter your Account number:");
				accountNum=sc.next();
				ActivityServices.validateAccountNumber(accountNum);
				}
				catch (InvalidAccountException e) {
					System.out.println("Invalid Account Number");break;
				}
				catch(InputMismatchException ime) {
					System.out.println("Give proper input");
				}
				
				AccountBean account3=services.getAccountServices(accountNum);
				if(account3==null)
				{
					System.out.println("Account doesn't exists!!");
					break;
				}
				try {
				System.out.println("Enter the amount to withdraw:");
				amount=sc.nextInt();
				ActivityServices.validateBalance(amount);
				}
				catch(BalanceException be) {
					System.out.println("Out of range amount");
				}
				catch(InputMismatchException ime) {
					System.out.println("Give proper input");
				}
				boolean res1=services.withdrawServices(accountNum,amount);
				if(res1==true) {
				transid+=10;
				Transaction t = new Transaction(transid, amount, "withdraw", "--	", "--		");	//transaction details
				services.setTransaction(accountNum, t);}
				break;
				
				
			case "4" :	//DEPOSIT
				amount=0;accountNum="";
				try {
				System.out.println("Enter your Account number:");
				accountNum=sc.next();
				ActivityServices.validateAccountNumber(accountNum);
				}
				catch (InvalidAccountException e) {
					System.out.println("Invalid Account Number");break;
				}
				catch(InputMismatchException ime) {
					System.out.println("Give proper input");
				}
				
				AccountBean account4=services.getAccountServices(accountNum);
				if(account4==null)
				{
					System.out.println("Account doesn't exists!!");
					break;
				}
				try {
				System.out.println("Enter the amount to deposit:");
				amount=sc.nextInt();
				ActivityServices.validateBalance(amount);
				}
				catch(BalanceException be) {
					System.out.println("Out of range amount");
				}
				catch(InputMismatchException ime) {
					System.out.println("Give proper input");
				}
				boolean res2=services.depositServices(accountNum,amount);
				if(res2==true)
				{
					transid+=10;
					Transaction t = new Transaction(transid, amount, "deposit", "--        ", "--   ");	//transaction details
					services.setTransaction(accountNum, t);
				}
				break;
			
			case "5" :		//SHOW BALANCE
				accountNum="";
				try { 
				System.out.println("Enter your Account number:");
				accountNum=sc.next();
				ActivityServices.validateAccountNumber(accountNum);
				}
				catch (InvalidAccountException e) {
					System.out.println("Invalid Account Number");break;
				}
				catch(InputMismatchException ime) {
					System.out.println("Give proper input");
				}
				
				AccountBean account5=services.getAccountServices(accountNum);
				if(account5==null)
				{
					System.out.println("Account doesn't exists!!");
					break;
				}
				System.out.println(account5.getCustName()+", your current Balance is Rs."+account5.getBalance());
				
				break;
			
			case "6" :		//PRINT TRANSACTION
				accountNum="";
				try {
				System.out.println("Enter your Account number:");
				accountNum=sc.next();
				ActivityServices.validateAccountNumber(accountNum);
				}
				catch (InvalidAccountException e) {
					System.out.println("Invalid Account Number");break;
				}
				catch(InputMismatchException ime) {
					System.out.println("Give proper input");
				}
				AccountBean account6=services.getAccountServices(accountNum);
				if(account6==null)
				{
					System.out.println("Account doesn't exists!!");
					break;
				}
				else {
					System.out.println("Transaction Details For:"+accountNum);
					System.out.println("TransId       Amount        Type         TransTo        TransFrom\n");
					services.printTransactions(accountNum);
				}
				break;
				
			case "7" :		//EXIT
				
				System.out.println("-----Hope you liked our services!!Thank You!!----");
				System.exit(0);
				default : 
					System.out.println("Invalid choice");
			}
		}
	}
		
}
	

